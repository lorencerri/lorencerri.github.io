var selected = 'home';

function element(name) {
    return document.getElementById(name);
}

function select(tab) {

    // Tab View
    element(selected).classList.remove('selected');
    element(tab).classList.add('selected');

    // Content View
    element(`${selected}Content`).setAttribute('style', 'display: none;')
    element(`${tab}Content`).setAttribute('style', 'display: block;')

    selected = tab;
}

updateTime()
setInterval(updateTime, 1000)

function updateTime() {
    var d = new Date();
    if (d.getHours() > 12) d.setHours(d.getHours() - 12);
    element('hour').innerHTML = d.getHours()
    element('minute').innerHTML = d.getMinutes()
    element('second').innerHTML = d.getSeconds()
    if (d.getHours() > 12) element('period').innerHTML = 'PM'
    else element('period').innerHTML = 'AM';
}
