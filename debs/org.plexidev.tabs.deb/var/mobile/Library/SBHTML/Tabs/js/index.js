var selected = 'home';

function element(name) {
    return document.getElementById(name);
}

function select(tab) {

    // Tab View
    if (selected) element(selected).classList.remove('selected');
    element(tab).classList.add('selected');
    selected = tab;

    // Content View

}
