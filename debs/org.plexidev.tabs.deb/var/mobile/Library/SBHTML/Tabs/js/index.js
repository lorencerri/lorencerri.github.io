var selected = 'home';

function element(name) {
    return document.getElementById(name);
}

function select(tab) {

    // Tab View
    if (selected || selected === tab) element(selected).classList.remove('selected');
    if (selected !== 'tab') element(tab).classList.add('selected');

    // Content View
    if (selected || selected === tab) element(`${selected}Content`).setAttribute('style', 'display: none;')
    if (selected !== tab) element(`${tab}Content`).setAttribute('style', 'display: block;')

    if (selected !== tab) selected = tab;
    else selected = null;
}

updateTime()
setInterval(updateTime, 1000)

function updateTime() {
    var d = new Date();
    if (d.getHours() > 12) d.setHours(d.getHours() - 12);
    element('hour').innerHTML = d.getHours()
    element('minute').innerHTML = d.getMinutes()
    element('second').innerHTML = d.getSeconds()
    if (d.getHours() > 12) element('period').innerHTML = 'PM'
    else element('period').innerHTML = 'AM';
}
