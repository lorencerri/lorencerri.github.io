// Variables
var selected;

// Functions
function element(name) { // Returns an element from the ID
    return document.getElementById(name);
}

function select(tab) { // Selects a tab & updates the view

    // Run if user clicks on different tab
    if (tab !== selected) {
        if (selected) element(`${selected}Content`).setAttribute('style', 'display:none;')
        element(`${tab}Content`).setAttribute('style', 'display:block;')
        selected = tab;
    }
    else { // Run if the user clicks on the same tab
        element(`${tab}Content`).setAttribute('style', 'display:none;')
        selected = false;
    }


}

function updateTime() { // Updates the time for the main tab

    // Variables
    var d = new Date();
    var period = 'AM';

    // Time Offset
    if (d.getHours() > 12) {
        period = 'PM';
        d.setHours(d.getHours() - 12);
    }

    // More Variables
    var hour = String(d.getHours()),
        minute = String(d.getMinutes());

    // Check Lengths
    if (minute.length < 2) minute = `0${minute}`;

    // Update View
    element('hour').innerHTML = hour;
    element('minute').innerHTML = minute;
    element('period').innerHTML = period;


}

// Execute Functions
updateTime();

// Execute Intervals
setInterval(updateTime, 60000);
